Check model output on drop box: 

https://www.dropbox.com/scl/fo/a5do9x3rik8wpzzb9685n/h?rlkey=fle6gv7gypr41etuivjqxg34a&dl=0


>> 3. Model