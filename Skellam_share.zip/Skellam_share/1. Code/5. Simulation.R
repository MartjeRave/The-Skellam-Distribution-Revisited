################################################################################
date_tod<-gsub("-", "_", as.character(Sys.Date()))
Sys.setlocale("LC_TIME", "English")
Sys.setenv("LANGUAGE"="English")


function_folder <- "Skellam_share"
functionpath<-substr(dirname(rstudioapi::getSourceEditorContext()$path), 
                     1, unlist(gregexpr(function_folder, 
                                        dirname(rstudioapi::getSourceEditorContext()$path)))+(nchar(function_folder)-1))

setwd(functionpath)

source("1. Code/0. Functions.R")


###########   Simulation from Skellam    #######################################

rdiffpois = function(lambda.in=lambda0.in, lambda.out=lambda0.out, D=data_training$Diff){
  
  max_prob_k=abs(max(data_training$Diff))*30
  
  
  k.in = matrix(rep(c(0: max_prob_k), each=length(lambda0.in)), nrow=length(lambda0.in))
  
  Din=matrix(rep(D, (max_prob_k+1)), nrow=length(lambda.in))
  k.out = k.in - Din
  index<-(k.in>=0)&(k.out>=0)
  
  
  I<-c()
  R<-c()
  
  
  for(i in 1:length(lambda0.in)){
    k.in.i = k.in[i,index[i,]]
    k.out.i = k.out[i,index[i,]]
    prob = dpois(k.in.i, lambda= lambda.in[i]) * dpois( k.out.i, lambda = lambda.out[i])
    x=sum(prob)
    prob = prob/x
    j = sample(length(prob), 1, prob=prob)
    
    I[i]<-k.in.i[j]
    R[i]<-k.out.i[j]
  }
  
  return(list( I = I, R = R))
}


################################################################################


simulation_data<-function(n=1000, ss=123,delta=0.1, fixed=TRUE){
  n1=n+1
  set.seed(ss)
  x1var<-1.397
  x1mean<-1.978
  
  X1<-rnorm(n1, x1mean, sqrt(x1var))
  
  if(fixed){
    b0in<--2.340
    b1in<-0.8
    
    b0out<-0.001
    b1out<-0.1  
  }else{
    b0in<-rnorm(1, -2.340, 0.0567)
    b1in<-rnorm(1,0.8, 0.0250)
    
    b0out<-rnorm(1, 0, 0.0725)
    b1out<-rnorm(1, 0.1, 0.0313)    
  }
  
  
  yin<-rpois(length(X1), lambda=exp(b0in+b1in*X1))
  
  
  data_training<-as.data.frame(cbind(yin, X1))
  
  
  
  
  X1temp<-X1[-1]
  yintemp<-yin[-length(yin)]
  
  
  yout<-rpois(length(X1temp),lambda=exp(b0out+b1out*X1temp
                                        #+b2out*X2+b3out*X3
                                        +log(yintemp+delta)))
  
  yout<-c(NA, yout)
  
  data_training$yout<-yout
  
  data_training$yin_lag1<-c(NA,yin[-length(yin)]) 
  
  data_training<-data_training[-1,] 
  data_training$Diff<-data_training$yin-data_training$yout
  return(list("Data"=data_training, "Coeff"=c(b0in,b1in,b0out,b1out)))
}

###########   Variance Calculation  ############################################
RubinVar<-function(Varianceruns=Run1$Coeff_var_in[200:500,,], Coefficientruns=Coeff_in[200:500,], runs=500){
  Rub1<-apply(Varianceruns,c(2,3),mean)
  betaminusbetaline<-(Coefficientruns-
                        matrix(rep(apply(Coefficientruns, 2, mean),
                                   each=nrow(Varianceruns)),
                               nrow=nrow(Varianceruns), ncol=ncol(Coefficientruns)))  
  variance_step<-array(NA,dim=c(nrow(betaminusbetaline), ncol(Coefficientruns),ncol(Coefficientruns)))
  for(i in 1:nrow(betaminusbetaline)){
    variance_step[i,,]<-t(as.matrix(betaminusbetaline[i,]))%*%
      as.matrix(betaminusbetaline[i,])
  }
  Rub2<-apply(variance_step,c(2,3),mean)
  Rubinvars<-Rub1+(1+1/nrow(Varianceruns))*(1/(nrow(Varianceruns)-1))*Rub2
  return(Rubinvars)
}

###########   Model Run  #######################################################
EMsimm<-function(train1=data_training, 
                 runs_tot=500, nr_coef=2, 
                 data_tot=data_training, 
                 delta_out=0.1){
  
  lambda0.in<-rep(sample(1:10,1), nrow(train1))
  lambda0.out<-rep(sample(11:20,1), nrow(train1))
  
  
  start_sim<-rdiffpois(lambda0.in,lambda0.out, train1$Diff)
  diff_sim<-as.data.frame(cbind("ind"=1:100, "sum_I"=1,"sum_R"=1))
  
  fitlist<-list()
  modellist<-list()
  Coeff_in<-NULL
  Coeff_out<-NULL
  
  VCOV<-matrix(0, nr_coef, nr_coef)
  Coeff_var_in<-array(NA, dim=c(runs_tot, nrow(VCOV),ncol(VCOV)))
  Coeff_var_out<-array(NA, dim=c(runs_tot, nrow(VCOV),ncol(VCOV)))
  
  
  for(k in 1:runs_tot){
    
    I_Mstep<-mgcv::gam(start_sim$I~X1, data=train1, family="poisson")
    R_Mstep<-mgcv::gam(start_sim$R~X1+offset(log(yin_lag1+delta_out)),data=train1, family="poisson")
    
    Coeff_var_in[k,,]<-vcov(I_Mstep)
    Coeff_var_out[k,,]<-vcov(R_Mstep)
    
    lambda.in.new<-predict.gam(I_Mstep, type="response")
    lambda.out.new<-predict.gam(R_Mstep, type="response")
    
    
    fitlist[[k]]<-rdiffpois(lambda.in.new,lambda.out.new, train1$Diff)
    start_sim<-as.data.frame(cbind("I"=fitlist[[k]]$I, "R"=fitlist[[k]]$R))
    modellist[[k]]<-list("I_mod"=I_Mstep,"R_mod"= R_Mstep)
    
    if(!is.null(Coeff_in)){
      suppressMessages(Coeff_in<-Coeff_in%>%
                         full_join(as.data.frame(t(coef(I_Mstep)))))
    }else{
      Coeff_in<-as.data.frame(t(coef(I_Mstep)))
      
    }
    if(!is.null(Coeff_out)){
      suppressMessages(Coeff_out<-Coeff_out%>%
                         full_join(as.data.frame(t(coef(R_Mstep)))))  
    }else{
      Coeff_out<-as.data.frame(t(coef(R_Mstep)))
    }
    
  }  
  
  Varin<-RubinVar(Varianceruns=Coeff_var_in[200:runs_tot,,], 
                  Coefficientruns=Coeff_in[200:runs_tot,], runs=500)
  Varout<-RubinVar(Varianceruns=Coeff_var_out[200:runs_tot,,], 
                   Coefficientruns=Coeff_out[200:runs_tot,], runs=500)
  
  
  return(list("Coeff_in"=Coeff_in, "Coeff_out"=Coeff_out, 
              "Coeff_var_in"=Coeff_var_in, "Coeff_var_out"=Coeff_var_out,
              "Varin"=Varin, "Varout"=Varout, "starvaluein"=unique(lambda0.in),
              "starvalueout"=unique(lambda0.out), "Models"=modellist, 
              "Response"=fitlist))
}


Sim_list<-list()

for(s in 1:20){
  
  data_simulated<-simulation_data(n=1000, ss=s, delta=0.1, fixed="True")
  
  data_training<-data_simulated$Data
  
  
  Sim1<-EMsimm()
  
  
  Rez<-cbind("I"=unlist(Sim1$Response)[grepl("I", names(unlist(Sim1$Response)))],
             "R"=unlist(Sim1$Response)[grepl("R", names(unlist(Sim1$Response)))])
  Rez<-cbind(Rez, "obs"=as.numeric(substr(row.names(Rez), 2, 
                                          nchar(row.names(Rez)))), 
             "Runs"=rep(1:400, each=1000))
  Rez<-as.data.frame(Rez)
  
  Rez_mean <- Rez %>%
    dplyr::filter(Runs>200)%>%
    dplyr::group_by(obs) %>%
    dplyr::summarize(I_mean = round(mean(I, na.rm=TRUE)),
                     R_mean = round(mean(R, na.rm=TRUE)))
  
  Coef_in_out<-cbind(Sim1$Coeff_in, Sim1$Coeff_out)
  names(Coef_in_out)<-c("In_Int", "In_X1", "Out_Int", "Out_X1")
  
  Sim_list[[s]]<-list("Estimated_coef"=Coef_in_out, "Rsults"=Rez_mean,"Real_vars"=data_simulated$Coeff, 
                      "Real_Data"=data_simulated$Data, Varin=Sim1$Varin, Varout=Sim1$Varout)
  saveRDS(Sim_list, 
          "4. Simulation/Simulations_paper.RData")
  print(s)
}




Sim_list<-readRDS("4. Simulation/Simulation_paper.RData")


coefficients<-NULL
for(i in 1:length(Sim_list)){
  coef_est<-apply(Sim_list[[i]]$Estimated_coef[200:nrow(Sim_list[[i]]$Estimated_coef),], 2, mean)
  coef_conf_in<-1.96*sqrt(diag(Sim_list[[i]]$Varin))
  coef_conf_out<-1.96*sqrt(diag(Sim_list[[i]]$Varout))
  coef_conf_min<-c(coef_est[1]-coef_conf_in[1], coef_est[2]-coef_conf_in[2], coef_est[3]-coef_conf_out[1], coef_est[4]-coef_conf_out[2])
  coef_conf_max<-c(coef_est[1]+coef_conf_in[1], coef_est[2]+coef_conf_in[2], coef_est[3]+coef_conf_out[1], coef_est[4]+coef_conf_out[2])
  real_est<-Sim_list[[i]]$Real_vars
  coefficients<-rbind(coefficients, c(coef_est, coef_conf_min, coef_conf_max, real_est))
}

coefficients<-as.data.frame(coefficients)
names(coefficients)<-c("Est_In_Int", "Est_In_X1", "Est_Out_Int", "Est_Out_X1", 
                       "LoCon_In_Int", "LoCon_In_X1", "LoCon_Out_Int", "LoCon_Out_X1", 
                       "UpCon_In_Int", "UpCon_In_X1", "UpCon_Out_Int", "UpCon_Out_X1", 
                       "Real_In_Int", "Real_In_X1", "Real_Out_Int", "Real_Out_X1")

coefficients$int<-1:nrow(coefficients)


gin_int<-ggplot(coefficients)+
  geom_point(aes(x=int, y=Real_In_Int))+
  geom_segment(aes(x=int, xend=int, y=LoCon_In_Int,  yend=UpCon_In_Int, col="Estimated Coefficient"))+
  geom_point(aes(x=int, y=Est_In_Int, col="Estimated Coefficient"))+
  theme(legend.position = "none")+
  geom_hline(aes(yintercept=0))+
  geom_hline(aes(yintercept=-2.340, col="Mean Simulated"))+
  xlab("Simulation Number")+
  ylab("Coefficient")+
  ggtitle("Incoming Intercept")+
  theme_pubr()+
  scale_color_manual(values=cbPalette[c(7,6)])+
  labs(col = "")

gin_x1<-ggplot(coefficients)+
  geom_point(aes(x=int, y=Real_In_X1))+
  geom_segment(aes(x=int, xend=int, y=LoCon_In_X1,  yend=UpCon_In_X1, col="Estimated Coefficient"))+
  geom_point(aes(x=int, y=Est_In_X1, col="Estimated Coefficient"))+
  theme(legend.position = "none")+
  geom_hline(aes(yintercept=0))+
  geom_hline(aes(yintercept=0.8, col="Mean Simulated"))+
  xlab("Simulation Number")+
  ylab("Coefficient")+
  ggtitle("Incoming X1")+
  theme_pubr()+
  scale_color_manual(values=cbPalette[c(7,6)])+
  labs(col = "")

gout_int<-ggplot(coefficients)+
  geom_point(aes(x=int, y=Real_Out_Int))+
  geom_segment(aes(x=int, xend=int, y=LoCon_Out_Int,  yend=UpCon_Out_Int, col="Estimated Coefficient"))+
  geom_point(aes(x=int, y=Est_Out_Int, col="Estimated Coefficient"))+
  theme(legend.position = "none")+
  geom_hline(aes(yintercept=0))+
  geom_hline(aes(yintercept=0, col="Mean Simulated"))+
  xlab("Simulation Number")+
  ylab("Coefficient")+
  ggtitle("Outgoing Intercept")+
  theme_pubr()+
  scale_color_manual(values=cbPalette[c(7,6)])+
  labs(col = "")

gout_x1<-ggplot(coefficients)+
  geom_point(aes(x=int, y=Real_Out_X1))+
  geom_segment(aes(x=int, xend=int, y=LoCon_Out_X1,  yend=UpCon_Out_X1, col="Estimated Coefficient"))+
  geom_point(aes(x=int, y=Est_Out_X1, col="Estimated Coefficient"))+
  theme(legend.position = "none")+
  geom_hline(aes(yintercept=0))+
  geom_hline(aes(yintercept=0.1, col="Mean Simulated"))+
  xlab("Simulation Number")+
  ylab("Coefficient")+
  ggtitle("Outgoing X1")+
  theme_pubr()+
  scale_color_manual(values=cbPalette[c(7,6)])+
  labs(col = "")

simulation_coefs<-plot_grid(gin_int,gin_x1,gout_int,gout_x1, ncol=2)

ggsave(simulation_coefs, 
       filename="4. Simulation/simulation_coeffcients.pdf",
       device="pdf", width=6, height=5)






















