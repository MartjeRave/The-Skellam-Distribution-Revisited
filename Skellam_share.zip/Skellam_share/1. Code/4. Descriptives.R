################################################################################
date_tod<-gsub("-", "_", as.character(Sys.Date()))
Sys.setlocale("LC_TIME", "English")
Sys.setenv("LANGUAGE"="English")


function_folder <- "Skellam_share"
functionpath<-substr(dirname(rstudioapi::getSourceEditorContext()$path), 
                     1, unlist(gregexpr(function_folder, 
                                        dirname(rstudioapi::getSourceEditorContext()$path)))+
                       (nchar(function_folder)-1))

setwd(functionpath)

source("1. Code/0. Functions.R")
train_tot<-readRDS("2. Data/2. Training Data/training_data.rds")
train<-train_tot
RKI_Divi_lag<-readRDS("2. Data/2. Training Data/training_data.rds")
results<-readRDS("3. Model/Model_500_runs.RData")

load("C:/Users/ra98jiq/Documents/Papers/Skellam_share/2. Data/0. Data Extra/district_data.RData")
load("C:/Users/ra98jiq/Documents/Papers/Skellam_share/2. Data/0. Data Extra/bundesland_data.RData")
district_data = st_set_crs(district_data,value = "EPSG:4326")
bundesland_data = st_set_crs(bundesland_data,value = "EPSG:4326")


################################################################################

maxvcap<-train%>%
  dplyr::filter(date<as.Date("2021-11-18"),date>as.Date("2021-10-01"))%>%
  dplyr::select(districtId, bed_tot)%>%
  dplyr::group_by(districtId)%>%
  dplyr::summarize(Max_ICU=max(bed_tot))  

maxvcap_train<-merge(district_data, maxvcap, by.x="lk_id", by.y="districtId", 
                     all=TRUE)

maxcap<-ggplot() +
  geom_sf(data = maxvcap_train, aes(fill=Max_ICU)) +
  theme_pubr() +
  geom_sf(data = bundesland_data, aes(), col = "black", alpha = 0.00001) +
  theme(axis.ticks = element_blank(),
        axis.text =  element_blank(),
        strip.text.y = element_text(size = 17),
        strip.text.x = element_text(size = 17),
        axis.line =  element_blank()) +
  scale_fill_gradient2(name = "", # option="G"
                       low = cbPalette[5], high = cbPalette[6],na.value="grey",
                       guide = guide_colourbar( barwidth = 8))+    
  theme(legend.position="bottom")+
  ggtitle("B) \n Maximum  total ICU capacity by district",
          paste("From", format(as.Date("2021-10-01"), format="%d %B %Y"), 
                "until", format(as.Date("2021-11-18"), format="%d %B %Y")))



plot_data<-RKI_Divi_lag%>%
  dplyr::filter(date<as.Date("2021-11-18"),date>as.Date("2021-10-01"))%>%
  dplyr::select(districtId, date, G_4_7, G_5_7, G_6_7, Diff)%>%
  dplyr::mutate(Infect_4=round(exp(G_4_7)-0.5,2),
                Infect_5=round(exp(G_5_7)-0.5,2), 
                Infect_6=round(exp(G_6_7)-0.5,2))%>%
  dplyr::group_by(date)%>%
  dplyr::summarize(Infect_4_mean=mean(Infect_4), 
                   Infect_5_mean=mean(Infect_5),
                   Infect_6_mean=mean(Infect_6),
                   Infect_4_025=quantile(Infect_4, 0.25), 
                   Infect_5_025=quantile(Infect_5, 0.25),
                   Infect_6_025=quantile(Infect_6, 0.25),
                   Infect_4_975=quantile(Infect_4, 0.75), 
                   Infect_5_975=quantile(Infect_5, 0.75),
                   Infect_6_975=quantile(Infect_6, 0.75),
                   Average_Diff=mean(Diff))

infect_rate_4<-ggplot(data=plot_data) +
  geom_ribbon(aes(x=date, ymin = Infect_4_025, ymax = Infect_4_975, fill="Inter quantile range"), 
              alpha = 0.2)+
  geom_line(aes(x=date, y=Infect_4_mean, col="Average"), size=1.1)+
  ggtitle("A) \n Infection rate per 100.000 inhabitants of the 35-59 year-olds",
          paste("From", format(as.Date("2021-10-01"), format="%d %B %Y"), 
                "until", format(as.Date("2021-11-18"), format="%d %B %Y")))+    
  theme(legend.position="none")+
  ylab("Infection rate")+
  xlab("Date")+
  theme_pubr()+ labs(fill='', col="")+
  scale_fill_manual(values=cbPalette[3])+
  scale_colour_manual(values=cbPalette[3]) 

infect_rate_5<-ggplot(data=plot_data) +  
  geom_ribbon(aes(x=date, ymin = Infect_5_025, ymax = Infect_5_975,
                  fill="Inter quantile range"), alpha = 0.2)+
  geom_line(aes(x=date, y=Infect_5_mean, col="Average"), size=1.1)+
  ggtitle("   Infection rate per 100.000 inhabitants of the 60-79 year-olds", " ")+    
  theme(legend.position="bottom")+
  ylab("Infection rate")+
  xlab("Date")+
  theme_pubr()+labs(fill='', col="")+
  scale_fill_manual(values=cbPalette[2])+
  scale_colour_manual(values=cbPalette[2])

infect_rate_6<-ggplot(data=plot_data) +
  geom_ribbon(aes(x=date, ymin = Infect_6_025, ymax = Infect_6_975, fill="Inter quantile range"), alpha = 0.2)+
  geom_line(aes(x=date, y=Infect_6_mean, col="Average"), size=1.1)+
  ggtitle("   Infection rate per 100.000 inhabitants of the 80+ year-olds",
          " ")+    
  theme(legend.position="bottom")+
  ylab("Infection rate")+
  xlab("Date")+
  theme_pubr()+labs(fill='', col="")+
  scale_fill_manual(values=cbPalette[1])+
  scale_colour_manual(values=cbPalette[1])

infections<-plot_grid(infect_rate_4,
          infect_rate_5,
          infect_rate_6, ncol=1)

descriptive_ov_time<-plot_grid(infections, maxcap)


# ggsave(descriptive_ov_time, file="2. Data/3. Descriptive/district_infect.pdf",
#        width = 11.8, height = 7.9)





#########################################################

survival<-c(0.20, 0.32, 0.4, 0.46, 0.51, 
            0.55, 0.57, 0.60, 0.63, 0.69,
            0.71, 0.73, 0.74, 0.77, 0.78,
            0.79,seq(0.82, 1, by=(1-0.82)/(56-17)))


ghaz<-ggplot()+
  geom_line(aes(x=1:56, y=survival*100), size=2)+
  xlab("Day")+
  ggtitle("Outgoing out of the ICU")+
  ylab("Percentage of patients (%)")+
  theme_pubr()


ggsave(ghaz, 
       file="2. Data/3. Descriptive/hazard.pdf",
       width=5, height=5)


#########################################################

# DIVI%>%
#   dplyr::group_by(date)%>%
#   dplyr::summarize(gesamt_betten=sum(faelle_covid_aktuell))%>%
#   ggplot()+
#   geom_line(aes(x=as.Date(date),y=gesamt_betten))



Incoming_response<-cbind(train[,c("districtId", "date")], 
                         as.data.frame(round(Incoming_response)))
Outgoing_response<-cbind(train[,c("districtId", "date")], 
                         as.data.frame(round(Outgoing_response)))

date_summ_in<-as.data.frame(matrix(0, ncol=ncol(Incoming_response)-2, 
                                   nrow=length(unique(Incoming_response$date))))
district_summ_in<-as.data.frame(matrix(0, ncol=ncol(Incoming_response)-2, 
                                       nrow=length(unique(Incoming_response$districtId))))

date_summ_out<-as.data.frame(matrix(0, ncol=ncol(Outgoing_response)-2, 
                                    nrow=length(unique(Outgoing_response$date))))
district_summ_out<-as.data.frame(matrix(0, ncol=ncol(Outgoing_response)-2, 
                                        nrow=length(unique(Outgoing_response$districtId))))

for(i in 1:length(unique(Incoming_response$districtId))){
  district_summ_in[i,]<-colSums(Incoming_response[Incoming_response$districtId==
                                                    unique(Incoming_response$districtId)[i],
                                           3:ncol(Incoming_response)])
  district_summ_out[i,]<-colSums(Outgoing_response[Outgoing_response$districtId==
                                                     unique(Outgoing_response$districtId)[i],
                                                  3:ncol(Outgoing_response)])
}

for(i in 1:length(unique(Incoming_response$date))){
  date_summ_in[i,]<-colSums(Incoming_response[Incoming_response$date==unique(Incoming_response$date)[i],
                                               3:ncol(Incoming_response)])
  date_summ_out[i,]<-colSums(Outgoing_response[Outgoing_response$date==unique(Outgoing_response$date)[i],
                                              3:ncol(Outgoing_response)])
}






