############################################################################################
date_tod<-gsub("-", "_", as.character(Sys.Date()))
Sys.setlocale("LC_TIME", "English")
Sys.setenv("LANGUAGE"="English")


function_folder <- "Skellam_share"
functionpath<-substr(dirname(rstudioapi::getSourceEditorContext()$path), 
                     1, unlist(gregexpr(function_folder, 
                     dirname(rstudioapi::getSourceEditorContext()$path)))+
                     (nchar(function_folder)-1))

setwd(functionpath)

source("1. Code/0. Functions.R")

train_tot<-readRDS("2. Data/2. Training Data/training_data.rds")

train<-train_tot%>%
  filter(date>as.Date("2021-10-01"), date<as.Date("2021-11-18"))

source("1. Code/0. Functions.R")

load("2. Data/0. Data Extra/district_data.RData")
load("2. Data/0. Data Extra/bundesland_data.RData")
district_data = st_set_crs(district_data,value = "EPSG:4326")
bundesland_data = st_set_crs(bundesland_data,value = "EPSG:4326")

################################################################################

 train1=train
 runs=500
 data_tot= train_tot
 formula_in<-as.formula(I_sim~ weekday+ s(as.numeric(date), bs="ps")+G_4_7_lag_1+
                           G_5_7_lag_1+ G_6_7_lag_1+ s(lat, long, bs="tp"))
 formula_out<-as.formula(R_sim~ weekday+ s(as.numeric(date), bs="ps")+G_4_7_lag_1+
                           G_5_7_lag_1+ G_6_7_lag_1+ s(lat, long, bs="tp"))
 
 
 
 
        # results<-EMsimm(runs1 = 500)
        # saveRDS(results, "3. Model/Model_500_runs.RData")
 
 results<-readRDS("3. Model/Model_500_runs.RData")
 
 ###############################################################################
 
 
 med_X<-as.data.frame(cbind(apply(results$Coeff_in[200:500,-1],2, median),
                            apply(results$Coeff_out[200:500,-1],2, median)
                            )[c(1,2,6,7,5,3,4,8,9,10),])
 
 names(med_X)<-c("Incoming", "Outgoing")
 
 results$VarInResults<-RubinVar(Varianceruns=results$Coeff_var_in[200:500,,], 
                                Coefficientruns=results$Coeff_in[200:500,-1], 
                                runs=500)
 results$VarOutResults<-RubinVar(Varianceruns=results$Coeff_var_out[200:500,,], 
                                 Coefficientruns=results$Coeff_out[200:500,-1], 
                                 runs=500)
 
 StdErrIn<-sqrt(diag(results$VarInResults))[c(1,2,6,7,5,3,4,8,9,10)]
 StdErrOut<-sqrt(diag(results$VarOutResults))[c(1,2,6,7,5,3,4,8,9,10)]
 
 
 med_X<-cbind("Incoming"=med_X$Incoming, "Incoming Str Err"=StdErrIn,
       "Outgoing"=med_X$Outgoing, "Outgoing Str Err"=StdErrOut)
 
 row.names(med_X)<-c("Intercept", 
                     "Monday Effect", 
                     "Tuesday Effect",
                     "Wednesday Effect",
                     "Thursday Effect",
                     "Saturday Effect",
                     "Sunday Effect",
                     "Infection 35-59 yo",
                     "Infection 60-79 yo",
                     "Infection 80+ yo")
 
 med_latex<-round(med_X,2)%>%
   kbl(caption="Coefficients estimated in models on incoming and outgoing patients",
       format="latex",
       align="c") %>%
   kable_minimal(full_width = F,  html_font = "Source Sans Pro")
 
 ############################################################################### 
 
 med_plot<-med_X
 rownames(med_plot)<-NULL
 
 med_plot<-cbind(as.data.frame(rbind(cbind("Incoming", rownames(med_X)),
      cbind("Outgoing", rownames(med_X)))), c(med_plot[,1], med_plot[,3]),
      c(med_plot[,2], med_plot[,4]))
 names(med_plot)<-c("label", "Variables", "Estimate", "StdErr")
 med_plot$y<-c(1:nrow(med_X), 1:nrow(med_X)-0.5) 
 
 
 
 Forest_plot<-ggplot()+
   geom_vline(aes(xintercept=0), col="red", lty=2)+
   geom_point(aes(x=Estimate ,y= y, col=label),
              data= med_plot[med_plot$Variables!="Intercept",])+
   geom_segment(aes(x=Estimate-1.96*StdErr, 
                    xend=Estimate+1.96*StdErr,
                    y=y,
                    yend=y, col=label),
                data= med_plot[med_plot$Variables!="Intercept",])+
   theme_pubr()+
   scale_color_manual(values=c("royalblue", "darkblue"))+
   theme(legend.title = element_blank(),
         axis.text.y = element_blank(),
         axis.ticks.y = element_blank(),
         axis.title.y = element_blank())+
   xlab( "Estimated coefficients")+
   geom_text(aes(x=(med_plot$Estimate)[
     med_plot$Variables!="Intercept"][1:(nrow(med_X)-1)], 
                  y=2:(nrow(med_X))), 
              label=unique(med_plot$Variables[med_plot$Variables!="Intercept"]),
     hjust=3.5)+
   coord_cartesian(xlim=c(-1,0.3))
 
 ggsave(Forest_plot,
        file=paste0("3. Model/Output_OctNov/Coefficient_forest.pdf"),
        device="pdf", width=6.81, height=3.19)
 
 
 ###############################################################################
 
 Coeff_in_=results$Coeff_out[,-1]
 k=200
 model_for_basis=results$Models[[1]]$R_mod
 label="Outgoing"
 wdepr="no"
 Var_in=results$VarOutResults


plotlistin<-plotsfunc(Coeff_in_=results$Coeff_in[,-1], 
                      k=200, 
                      model_for_basis=results$Models[[1]]$R_mod, 
                      label="Incoming",
                       wdepr="no", Var_in=results$VarInResults)

plotlistout<-plotsfunc(Coeff_in_=results$Coeff_out[,-1], 
                       k=200, 
                       model_for_basis=results$Models[[1]]$R_mod, 
                       label="Outgoing",
                       wdepr="no", 
                       Var_in=results$VarOutResults)


coefplots<-plot_grid(plotlistin$Coefficient, plotlistout$Coefficient, ncol=2)





plotlistin$Time<-plotlistin$Time+
  coord_cartesian(ylim=c(-0.45, 0.3))
plotlistout$Time<-plotlistout$Time+
  coord_cartesian(ylim=c(-0.45, 0.3))

time<-plot_grid(plotlistin$Time, plotlistout$Time, ncol=2)
space<-plot_grid(plotlistin$Long_Lat_median, plotlistout$Long_Lat_median, ncol=2)



# ggsave(plotlistin$Coefficient,
#        file=paste0("3. Model/Output_OctNov/Coefficients_Incoming.pdf"),
#        device="pdf", width=5, height=8)
# 
# ggsave(plotlistout$Coefficient,
#        file=paste0("3. Model/Output_OctNov/Coefficients_Outgoing.pdf"),
#        device="pdf", width=5, height=8)
# 
ggsave(time,
       file=paste0("3. Model/Output_OctNov/Time_smooth.pdf"),
       device="pdf", width=6.81, height=3.19)
# 
# ggsave(space,
#        file=paste0("3. Model/Output_OctNov/space_smooth.pdf"),
#        device="pdf", width=4, height=4)

 
################################################################################

Incoming_response<-matrix(NA, nrow=nrow(results$Models[[1]]$I_mod$model),
                          ncol=length(results$Models))
Outgoing_response<-matrix(NA, nrow=nrow(results$Models[[1]]$R_mod$model), 
                          ncol=length(results$Models))

for(i in 1:length(results$Models)){
  Incoming_response[,i]<-results$Models[[i]]$I_mod$model$I_sim
  Outgoing_response[,i]<-results$Models[[i]]$R_mod$model$R_sim
}


colnames(Incoming_response)<-paste0("Run_", seq(1, 500))
colnames(Outgoing_response)<-paste0("Run_", seq(1, 500))

Incoming_response<-cbind("districtId"=train$districtId, 
                         "date"=train$date, as.data.frame(Incoming_response))
Outgoing_response<-cbind("districtId"=train$districtId,
                         "date"=train$date, as.data.frame(Outgoing_response))

## Function in 0. Functions
Summ_dist_inc<-Summary_by_run(Incoming_response, Incoming_response$districtId)
Summ_date_inc<-Summary_by_run(Incoming_response, Incoming_response$date)
Summ_dist_out<-Summary_by_run(Outgoing_response, Outgoing_response$districtId)
Summ_date_out<-Summary_by_run(Outgoing_response, Outgoing_response$date)

DIVI<-readRDS("2. Data/1. Data Download/RKI DIVI in analysis/DIVI_2022-10-27.rds")

tot_cov_beds<-DIVI%>%
  filter(date>as.Date("2021-10-01"), date<as.Date("2021-11-18"))%>%
  dplyr::group_by(date)%>%
  dplyr::summarize(Covid_beds=sum(faelle_covid_aktuell))

max_sum<-cbind(as.data.frame(Summ_date_out[,"groupId"]), 
               "Incoming"=apply(Summ_date_inc[, 301:501],1, max), 
               "Outgoing"=apply(Summ_date_out[, 301:501],1, max))
min_sum<-cbind(as.data.frame(Summ_date_out[,"groupId"]), 
               "Incoming"=apply(Summ_date_inc[, 301:501],1, min), 
               "Outgoing"=apply(Summ_date_out[, 301:501],1, min))
mean_sum<-cbind(as.data.frame(Summ_date_out[,"groupId"]), 
                "Incoming"=apply(Summ_date_inc[, 301:501],1, mean), 
                "Outgoing"=apply(Summ_date_out[, 301:501],1, mean))
median_sum<-cbind(as.data.frame(Summ_date_out[,"groupId"]), 
                  "Incoming"=apply(Summ_date_inc[, 301:500],1, median), 
                  "Outgoing"=apply(Summ_date_out[, 301:500],1, median))

date_sum<-ggplot()+
  geom_area(aes(x=mean_sum$groupId, y=mean_sum$Incoming, fill="Incoming"), 
            alpha = 0.2, fill=cbPalette[3])+
  geom_area(aes(x=mean_sum$groupId, y=mean_sum$Outgoing), fill="white")+
  geom_line(aes(x=mean_sum$groupId, y=mean_sum$Outgoing, col="Outgoing"), size=1.05)+
  geom_line(aes(x=mean_sum$groupId, y=mean_sum$Incoming, col="Incoming"), size=1.05)+
  geom_line(aes(x=as.Date(tot_cov_beds$date), y=(tot_cov_beds$Covid_beds)*0.09, 
                col="Total Covid ICU Beds"), size=1.2)+
  scale_y_continuous(
    name = "Estimated incoming and outgoing \n patients in Germany",
    sec.axis = sec_axis(~(.)/0.09, name="Total COVID ICU beds in Germany")
  ) +
  xlab("date")+
  theme_pubr()+
  scale_fill_manual(values=cbPalette)+
  scale_colour_manual(values=cbPalette)+
  labs(colour="")+
  ggtitle("Incoming and outgoing patients (left hand y-axis) \n and total occupancy of ICU beds over time \n (right hand y-axis) in Germany")+ 
  #scale_x_date(date_labels = "%d/%m/%Y")+ 
  guides(fill="none")


# ggsave(date_sum,
#        file=paste0("3. Model/Output_OctNov/Estimated_date_sum.pdf"),
#        device="pdf", width=5.5, height=4)


