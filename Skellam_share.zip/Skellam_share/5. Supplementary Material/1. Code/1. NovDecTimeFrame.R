############################################################################################
date_tod<-gsub("-", "_", as.character(Sys.Date()))
Sys.setlocale("LC_TIME", "English")
Sys.setenv("LANGUAGE"="English")


function_folder <- "Skellam_share"
functionpath<-substr(dirname(rstudioapi::getSourceEditorContext()$path), 
                     1, unlist(gregexpr(function_folder, 
                                        dirname(rstudioapi::getSourceEditorContext()$path)))+
                       (nchar(function_folder)-1))

setwd(functionpath)

source("1. Code/0. Functions.R")

train_tot<-readRDS("2. Data/2. Training Data/training_data.rds")

train<-train_tot%>%
  filter(date>as.Date("2021-10-01"), date<as.Date("2021-11-18"))


############################################################################################

train_tot%>%
  dplyr::select(date, Diff)%>%
  dplyr::group_by(date)%>%
  dplyr::summarize(Sum_Diff=sum(Diff))%>%
  ggplot()+
  geom_line(aes(x=date, y=Sum_Diff))+
  geom_vline(aes(xintercept=as.Date("2021-10-01")), col="red")+
  geom_vline(aes(xintercept=as.Date("2021-11-18")), col="red")+
  geom_vline(aes(xintercept=as.Date("2021-11-19")), col="blue")+
  geom_vline(aes(xintercept=as.Date("2021-12-31")), col="blue")

test<-train_tot%>%
  filter(date>as.Date("2021-11-19"), date<as.Date("2021-12-20"))

################################################################################
# model_test<-EMsimm(train_train=test, 
#                    runs1=500, 
#                    data_tot= train_tot,
#                    formula_in=as.formula(I_sim ~ weekday + s(as.numeric(date), bs = "ps") + G_4_7_lag_1 + 
#                                            G_5_7_lag_1 + G_6_7_lag_1 + s(lat, long, bs = "tp")), 
#                    formula_out=as.formula(R_sim ~ weekday + s(as.numeric(date), bs = "ps") + G_4_7_lag_1 + 
#                                             G_5_7_lag_1 + G_6_7_lag_1 + s(lat, long, bs = "tp")),
#                    nr_coefficients=48)
# 
# 
# 
# model_test$Variance_out<-RubinVar(Varianceruns=model_test$Coeff_var_out[200:500,,], 
#                                   Coefficientruns=model_test$Coeff_out[200:500,-1], 
#                                   runs=300)
# 
# model_test$Variance_in<-RubinVar(Varianceruns=model_test$Coeff_var_in[200:500,,], 
#                                  Coefficientruns=model_test$Coeff_in[200:500,-1], 
#                                  runs=300)
# 
# save(model_test, file="3. Model/NovDecAppl.RData")
################################################################################

load("C:/Users/ra98jiq/Documents/Papers/Skellam_share/3. Model/NovDecAppl.RData")

plot_list_out<-plotsfunc(Coeff_in_=model_test$Coeff_out[,-1], 
                         k=1, 
                         model_for_basis=model_test$Models,
                         training_data=test, 
                         label=c("Outgoing"),
                         wdepr=c("no"), Var_in=model_test$Variance_out)

plot_list_in<-plotsfunc(Coeff_in_=model_test$Coeff_in[,-1], 
                        k=1, 
                        model_for_basis=model_test$Models,
                        training_data=test, 
                        label=c("Incoming"),
                        wdepr=c("no"), Var_in=model_test$Variance_out)



test_plot_coef<-plot_grid(plot_list_in$Coefficient, plot_list_out$Coefficient, ncol=2)
test_plot_time<-plot_grid(plot_list_in$Time, plot_list_out$Time, ncol=2)
test_plot_space<-plot_grid(plot_list_in$Long_Lat_median, plot_list_out$Long_Lat_median, ncol=2)



# ggsave(test_plot_coef, 
#        file="3. Model/Output_NovDec/Coefficients.pdf",
#        height=10, width=8)
# 
# ggsave(test_plot_time, 
#        file="3. Model/Output_NovDec/Time.pdf",
#        height=6, width=10)
# 
# ggsave(test_plot_space, 
#        file="3. Model/Output_NovDec/Space.pdf",
#        height=6, width=8)

Incoming<-test[,c("districtId", "date")]
Outgoing<-test[,c("districtId", "date")]
Incoming_pred<-test[,c("districtId", "date")]
Outgoing_pred<-test[,c("districtId", "date")]

for(i in 1:length(model_test$Response)){
  Incoming$Incom<-model_test$Response[[i]]$I
  names(Incoming)[length(names(Incoming))]<-paste0("Incom_run_", i)
  Outgoing$Outg<-model_test$Response[[i]]$R
  names(Outgoing)[length(names(Outgoing))]<-paste0("Outg_run_", i)
  Incoming_pred$Incom<-predict(results$Models[[i]]$I_mod, test, type="response")
  names(Incoming_pred)[length(names(Incoming_pred))]<-paste0("Incom_run_", i)
  Outgoing_pred$Outg<-predict(results$Models[[i]]$R_mod, test, type="response")
  names(Outgoing_pred)[length(names(Outgoing_pred))]<-paste0("Outg_run_", i)
}

Incoming_sum<-cbind(test[,c("districtId", "date")], "Incoming"=
                      apply(Incoming[,203:ncol(Incoming)],1, median))%>%
  dplyr::group_by(date)%>%
  dplyr::summarize("Incoming"=sum(Incoming))
Outgoing_sum<-cbind(test[,c("districtId", "date")], "Outgoing"=
                      apply(Outgoing[,203:ncol(Outgoing)],1, median))%>%
  dplyr::group_by(date)%>%
  dplyr::summarize("Outgoing"=sum(Outgoing))


Incoming_pred_sum<-cbind(test[,c("districtId", "date")], "Incoming"=
                           apply(Incoming_pred[,203:ncol(Incoming_pred)],1, median))%>%
  dplyr::group_by(date)%>%
  dplyr::summarize("Incoming"=sum(Incoming))
Outgoing_pred_sum<-cbind(test[,c("districtId", "date")], "Outgoing"=
                           apply(Outgoing_pred[,203:ncol(Outgoing_pred)],1, median))%>%
  dplyr::group_by(date)%>%
  dplyr::summarize("Outgoing"=sum(Outgoing))



gnumb<-ggplot()+
  geom_line(aes(x=Incoming_sum$date, y=Incoming_sum$Incoming, col="Incoming"))+
  geom_line(aes(x=Outgoing_sum$date, y=Outgoing_sum$Outgoing, col="Outgoing"))+
  geom_line(aes(x=Incoming_sum$date, y=Incoming_pred_sum$Incoming, col="Predicted \n Incoming"))+
  geom_line(aes(x=Outgoing_sum$date, y=Outgoing_pred_sum$Outgoing, col="Predicted \n Outgoing"))+
  ylab("Number of patients")+
  xlab("Date")+
  ggtitle("Number of incoming and outgoing number of estimated patients")+
  scale_color_manual(values=cbPalette)

gnumb_pred<-ggplot()+
  geom_line(aes(x=Incoming_sum$date, y=Incoming_sum$Incoming, col="Predicted \n Incoming"))+
  geom_line(aes(x=Outgoing_sum$date, y=Outgoing_sum$Outgoing, col="Predicted \n Outgoing"))+
  ylab("Number of patients")+
  xlab("Date")+
  ggtitle("Predicted number of incoming and outgoing number of estimated patients")+
  scale_color_manual(values=cbPalette[3:4])

Diff_sum<-cbind(test[,c("districtId", "date", "Diff")])%>%
  dplyr::group_by(date)%>%
  dplyr::summarize("Diff"=sum(Diff))

gdiff<-ggplot(data=Diff_sum)+
  geom_line(aes(x=date, y=Diff, col="Difference"))+
  ylab("Number of patients")+
  xlab("Date")+
  ggtitle("Difference in the number of patients")

# ggsave(plot_grid(gnumb, gdiff, ncol=1), 
#        file="3. Model/Output_NovDec/NumbPat.pdf",
#        height=6, width=8)


################################################################################


results<-readRDS("3. Model/Model_500_runs.RData")

med_test<-as.data.frame(cbind(apply(model_test$Coeff_in[200:500,-1],2, 
                                      median),
                                apply(model_test$Coeff_out[200:500,-1],2, 
                                      median))[c(1,2,6,7,5,3,4,8,9,10),])

row.names(med_test)<-c("Intercept", 
                         "Monday Effect", 
                         "Tuesday Effect",
                         "Wednesday Effect",
                         "Thursday Effect",
                         "Saturday Effect",
                         "Sunday Effect",
                         "Infection 35-59 yo",
                         "Infection 60-79 yo",
                         "Infection 80+ yo")
names(med_test)<-c("Incoming", "Outgoing")

model_test$VarIn<-RubinVar(Varianceruns=model_test_maxIn$Coeff_var_in[200:500,,], 
                                 Coefficientruns=model_test_maxIn$Coeff_in[200:500,-1], 
                                 runs=500)
model_test$VarOut<-RubinVar(Varianceruns=model_test_maxIn$Coeff_var_out[200:500,,], 
                                 Coefficientruns=model_test_maxIn$Coeff_out[200:500,-1], 
                                 runs=500)

med_test<-cbind("Incoming"=med_test$Incoming,
      "Incoming Std Err"=sqrt(diag(model_test$VarIn))[c(1,2,6,7,5,3,4,8,9,10)],
      "Outgoing"=med_test$Outgoing,
      "Outgoing Std Err"=sqrt(diag(model_test$VarOut))[c(1,2,6,7,5,3,4,8,9,10)])
  
med_X<-as.data.frame(cbind(apply(results$Coeff_in[200:500,-1],2, median),
                           apply(results$Coeff_out[200:500,-1],2, median))[
                             c(1,2,6,7,5,3,4,8,9,10),])

row.names(med_X)<-names(apply(results$Coeff_out[12,-1],2, median))[
  c(1,2,6,7,5,3,4,8,9,10)]

med_latex_Inco_outgo<-cbind("Names"=row.names(med_X),
                            round(cbind(
                              "Incoming Coeff k=1000"=med_X[,1], 
                              "Incoming Coeff k=2000"=med_X_test[,1], 
                              "Outgoing Coeff k=1000"=med_X[,2], 
                              "Outgoing Coeff k=2000"=med_X_test[,2]),2)) %>%
  kbl(caption="Coefficients estimated in models on incoming and outgoing patients",
      format="latex",
      align="c") %>%
  kable_minimal(full_width = F,  html_font = "Source Sans Pro")

