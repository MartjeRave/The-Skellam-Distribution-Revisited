############################################################################################
date_tod<-gsub("-", "_", as.character(Sys.Date()))
Sys.setlocale("LC_TIME", "English")
Sys.setenv("LANGUAGE"="English")


function_folder <- "Skellam_share"
functionpath<-substr(dirname(rstudioapi::getSourceEditorContext()$path), 
                     1, unlist(gregexpr(function_folder, 
                                        dirname(rstudioapi::getSourceEditorContext()$path)))+
                       (nchar(function_folder)-1))

setwd(functionpath)

source("0. Functions/Functions.R")

train_tot<-readRDS("2. Data/2. Training Data/training_data.rds")

train<-train_tot%>%
  filter(date>as.Date("2021-10-01"), date<as.Date("2021-11-18"))

############################################################################################

Sim_list<-readRDS("4. Simulation/Simulations_paper.RData")


estimatedIncom1<-ggplot()+
  geom_line(aes(x=(1:length(Sim_list[[1]]$Rsults$I_mean))/length(Sim_list[[1]]$Rsults$I_mean)*17, 
                y=(1:length(Sim_list[[1]]$Rsults$I_mean))/length(Sim_list[[1]]$Rsults$I_mean)*17),
            col=cbPalette[7])+
  geom_point(aes(y=Sim_list[[1]]$Rsults$I_mean, 
                 x=Sim_list[[1]]$Real_Data$yin),
             alpha=0.1, col=cbPalette[7])+
  theme_pubr()+
  xlab("Real")+
  ylab("Estimated")+
  ggtitle("Simulation 1: Incoming Patients")


estimatedOutgo1<-ggplot()+
  geom_line(aes(x=(1:length(Sim_list[[1]]$Rsults$R_mean))/length(Sim_list[[1]]$Rsults$R_mean)*19, 
                y=(1:length(Sim_list[[1]]$Rsults$R_mean))/length(Sim_list[[1]]$Rsults$R_mean)*19),
            col=cbPalette[6])+
  geom_point(aes(y=Sim_list[[1]]$Rsults$R_mean, 
                 x=Sim_list[[1]]$Real_Data$yout),
             alpha=0.1, col=cbPalette[6])+
  theme_pubr()+
  xlab("Real")+
  ylab("Estimated")+
  ggtitle("Simulation 1: Outgoing Patients")



estimatedIncom2<-ggplot()+
  geom_line(aes(x=(1:length(Sim_list[[2]]$Rsults$I_mean))/length(Sim_list[[2]]$Rsults$I_mean)*17, 
                y=(1:length(Sim_list[[2]]$Rsults$I_mean))/length(Sim_list[[2]]$Rsults$I_mean)*17),
            col=cbPalette[7])+
  geom_point(aes(y=Sim_list[[2]]$Rsults$I_mean, 
                 x=Sim_list[[2]]$Real_Data$yin),
             alpha=0.1, col=cbPalette[7])+
  theme_pubr()+
  xlab("Real")+
  ylab("Estimated")+
  ggtitle("Simulation 2: Incoming Patients")


estimatedOutgo2<-ggplot()+
  geom_line(aes(x=(1:length(Sim_list[[2]]$Rsults$R_mean))/length(Sim_list[[2]]$Rsults$R_mean)*19, 
                y=(1:length(Sim_list[[2]]$Rsults$R_mean))/length(Sim_list[[2]]$Rsults$R_mean)*19),
            col=cbPalette[6])+
  geom_point(aes(y=Sim_list[[2]]$Rsults$R_mean, 
                 x=Sim_list[[2]]$Real_Data$yout),
             alpha=0.1, col=cbPalette[6])+
  theme_pubr()+
  xlab("Real")+
  ylab("Estimated")+
  ggtitle("Simulation 2: Outgoing Patients")



estimatedIncom3<-ggplot()+
  geom_line(aes(x=(1:length(Sim_list[[3]]$Rsults$I_mean))/length(Sim_list[[3]]$Rsults$I_mean)*17, 
                y=(1:length(Sim_list[[3]]$Rsults$I_mean))/length(Sim_list[[3]]$Rsults$I_mean)*17),
            col=cbPalette[7])+
  geom_point(aes(y=Sim_list[[3]]$Rsults$I_mean, 
                 x=Sim_list[[3]]$Real_Data$yin),
             alpha=0.1, col=cbPalette[7])+
  theme_pubr()+
  xlab("Real")+
  ylab("Estimated")+
  ggtitle("Simulation 3: Incoming Patients")


estimatedOutgo3<-ggplot()+
  geom_line(aes(x=(1:length(Sim_list[[3]]$Rsults$R_mean))/length(Sim_list[[3]]$Rsults$R_mean)*19, 
                y=(1:length(Sim_list[[3]]$Rsults$R_mean))/length(Sim_list[[3]]$Rsults$R_mean)*19),
            col=cbPalette[6])+
  geom_point(aes(y=Sim_list[[3]]$Rsults$R_mean, 
                 x=Sim_list[[3]]$Real_Data$yout),
             alpha=0.1, col=cbPalette[6])+
  theme_pubr()+
  xlab("Real")+
  ylab("Estimated")+
  ggtitle("Simulation 3: Outgoing Patients")


sim1<-plot_grid(estimatedIncom1, estimatedOutgo1, nrow=1)
sim2<-plot_grid(estimatedIncom2, estimatedOutgo2, nrow=1)
sim3<-plot_grid(estimatedIncom3, estimatedOutgo3, nrow=1)


# ggsave(plot_grid(sim1, sim2, sim3, ncol=1),
#        file="4. Simulation/SimulationRealvsEst.pdf",
#        device="pdf",
#        width=7, height=10)



