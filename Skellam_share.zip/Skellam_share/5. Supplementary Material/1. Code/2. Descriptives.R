
################################################################################
date_tod<-gsub("-", "_", as.character(Sys.Date()))
Sys.setlocale("LC_TIME", "English")
Sys.setenv("LANGUAGE"="English")


function_folder <- "Skellam_share"
functionpath<-substr(dirname(rstudioapi::getSourceEditorContext()$path), 
                     1, unlist(gregexpr(function_folder, 
                        dirname(rstudioapi::getSourceEditorContext()$path)))+
                       (nchar(function_folder)-1))

setwd(functionpath)

source("1. Code/0. Functions.R")
train_tot<-readRDS("2. Data/2. Training Data/training_data.rds")
train<-train_tot
RKI_Divi_lag<-readRDS("2. Data/2. Training Data/training_data.rds")
results<-readRDS("3. Model/Model_500_runs.RData")

load("2. Data/0. Data Extra/district_data.RData")
load("2. Data/0. Data Extra/bundesland_data.RData")
district_data = st_set_crs(district_data,value = "EPSG:4326")
bundesland_data = st_set_crs(bundesland_data,value = "EPSG:4326")


################################################################################

data_pairs<-train1[,c("G_4_7_lag_1", "G_5_7_lag_1", "G_6_7_lag_1")]

names(data_pairs)<-c("35-59 year olds","60-79 year olds","80+ year olds")
pairsplots<-pairs.panels(data_pairs,
                         smooth = TRUE,      # If TRUE, draws loess smooths
                         scale = FALSE,      # If TRUE, scales the correlation text font
                         density = TRUE,     # If TRUE, adds density plots and histograms
                         ellipses = TRUE,    # If TRUE, draws ellipses
                         method = "pearson", # Correlation method (also "spearman" or "kendall")
                         pch = 21,           # pch symbol
                         lm = FALSE,         # If TRUE, plots linear fit rather than the LOESS (smoothed) fit
                         cor = TRUE,         # If TRUE, reports correlations
                         jiggle = FALSE,     # If TRUE, data points are jittered
                         factor = 2,         # Jittering factor
                         hist.col = 4,       # Histograms color
                         stars = TRUE,       # If TRUE, adds significance level with stars
                         ci = TRUE)          # If TRUE, adds confidence intervals

################################################################################



max_bed_time<-as.data.frame(unique(cbind("groupId"=
                                           as.numeric(DIVI[, "gemeindeschluessel"]), 
                                         "bed_tot"=DIVI$betten_belegt+DIVI$betten_frei)))%>%
  group_by(groupId)%>%
  dplyr::summarize(bed_tot=median(bed_tot))


name<-unique(RKI_Divi_lag[,c("districtId","district", "geometry")])%>%
  mutate(districtId=as.numeric(districtId))

District<-as.data.frame(cbind("groupId"=as.numeric(unlist(Summ_dist_inc[,1])), 
                              "Incoming"=apply(Summ_dist_inc[,200:500], 1, median),
                              "Outgoing"=apply(Summ_dist_out[,200:500], 1, median)))%>%
  full_join(max_bed_time, by = "groupId")%>%
  mutate(Incoming_per=Incoming/bed_tot*100, 
         Outgoing_per=Outgoing/bed_tot*100)%>%
  full_join(name, by = c("groupId"="districtId"))%>%
  arrange(desc(Incoming))
#

Incoming_res_med_name<-Incoming_res_med%>%
  mutate(districtId=as.numeric(districtId))%>%
  inner_join(name)

ggplot(Incoming_res_med_name[Incoming_res_med_name$districtId%in%
                               c(District$groupId[2]),])+
  geom_line(aes(x=date, y=Incoming, col=district))+
  geom_point(aes(x=date, y=Incoming, col=district))+
  scale_color_manual(values=cbPalette)+
  labs(title="DistrictId")


District <- st_as_sf(District)
max_Incoming<-ggplot() +
  geom_sf(data = District, aes(fill=Incoming)) +
  theme_pubr() +
  geom_sf(data = District, aes(), col = "black", alpha = 0.00001) +
  theme(axis.ticks = element_blank(),
        axis.text =  element_blank(),
        strip.text.y = element_text(size = 17),
        strip.text.x = element_text(size = 17),
        axis.line =  element_blank()) +
  scale_fill_gradient2(name = "", # option="G"
                       low = cbPalette[5], high = cbPalette[7],na.value="grey",
                       guide = guide_colourbar( barwidth = 8))+    
  theme(legend.position="bottom")+
  ggtitle("A) Maximum estimated \n number of incoming \n patients by district")

max_Outgoing<-ggplot() +
  geom_sf(data = District, aes(fill=Outgoing)) +
  theme_pubr() +
  geom_sf(data = District, aes(), col = "black", alpha = 0.00001) +
  theme(axis.ticks = element_blank(),
        axis.text =  element_blank(),
        strip.text.y = element_text(size = 17),
        strip.text.x = element_text(size = 17),
        axis.line =  element_blank()) +
  scale_fill_gradient2(name = "", # option="G"
                       low = cbPalette[5], high = cbPalette[6],na.value="grey",
                       guide = guide_colourbar( barwidth = 8))+    
  theme(legend.position="bottom")+
  ggtitle("B) Maximum estimated \n number of outgoing \n patients by district")

#

plot_district_max_inc_out<-plot_grid(max_Incoming, max_Outgoing)

# ggsave(plot_district_max_inc_out, 
#        file="3. Model/Output/plot_district_max_inc_out.pdf",
#        width=5, height=5)



