############################################################################################
date_tod<-gsub("-", "_", as.character(Sys.Date()))
Sys.setlocale("LC_TIME", "English")
Sys.setenv("LANGUAGE"="English")


function_folder <- "Skellam_share"
functionpath<-substr(dirname(rstudioapi::getSourceEditorContext()$path), 
                     1, unlist(gregexpr(function_folder, 
                                        dirname(rstudioapi::getSourceEditorContext()$path)))+
                       (nchar(function_folder)-1))

setwd(functionpath)

source("1. Code/0. Functions.R")

train_tot<-readRDS("2. Data/2. Training Data/training_data.rds")

train<-train_tot%>%
  filter(date>as.Date("2021-10-01"), date<as.Date("2021-11-18"))

source("1. Code/0. Functions.R")

load("2. Data/0. Data Extra/district_data.RData")
load("2. Data/0. Data Extra/bundesland_data.RData")
district_data = st_set_crs(district_data,value = "EPSG:4326")
bundesland_data = st_set_crs(bundesland_data,value = "EPSG:4326")

################################################################################

train1=train
runs=500
data_tot= train_tot
formula_in<-as.formula(I_sim~ weekday+ s(as.numeric(date), bs="ps")+G_4_7_lag_1+
                         G_5_7_lag_1+ G_6_7_lag_1+ s(lat, long, bs="tp"))
formula_out<-as.formula(R_sim~ weekday+ s(as.numeric(date), bs="ps")+G_4_7_lag_1+
                          G_5_7_lag_1+ G_6_7_lag_1+ s(lat, long, bs="tp"))




# results<-EMsimm(runs1 = 500)
# saveRDS(results, "3. Model/Model_500_runs.RData")

results<-readRDS("3. Model/Model_500_runs.RData")

###############################################################################

resultsModel<-NULL
for(i in 200:500){
  if(is.null(resultsModel)){
    resultsModel<-cbind(results$Response[[i]]$I, 
                        results$Response[[i]]$R)
  }
  resultsModel<-resultsModel+ cbind(results$Response[[i]]$I, 
                                    results$Response[[i]]$R) 
  
}


Diff_train<-train%>%
  dplyr::filter(date<as.Date("2021-11-18"),date>as.Date("2021-10-01"))%>%
  dplyr::select(Diff)

Residuals<-cbind("True"=Diff_train, "Simulated"=rpois(length(resultsModel[,1]), resultsModel[,1]/300)-
                   rpois(length(resultsModel[,2]), resultsModel[,2]/300))

ghist<-ggplot()+
  geom_bar(aes(Residuals$Diff-Residuals$Simulated), fill="grey50")+
  theme_pubr()+
  labs(x=expression(Delta- Delta~"*"),
       y="Frequency")+
       ggtitle(expression(atop(paste("Difference in observed difference in occupancy," ~Delta*", and the"), 
                  paste("difference in simulated incoming and outgoing patients,"~ Delta~ "*"))),
               "Based on the estimated intensities over the last 300 runs")+
  scale_x_continuous(breaks=-4:4)+
  coord_cartesian(xlim=c(-5,5))


ggsave(ghist, 
       filename="3. Model/Output_OctNov/HistogramDiffinSimulatedObserved.pdf",
       device="pdf", width=6.3, height=5)

ggsave(ghist, 
       filename="3. Model/Output_OctNov/HistogramDiffinSimulatedObserved.png",
       device="png", width=6.3, height=5)





















