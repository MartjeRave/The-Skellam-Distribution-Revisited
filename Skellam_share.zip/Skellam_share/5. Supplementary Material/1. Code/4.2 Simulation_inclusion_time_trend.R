################################################################################
date_tod<-gsub("-", "_", as.character(Sys.Date()))
Sys.setlocale("LC_TIME", "English")
Sys.setenv("LANGUAGE"="English")


function_folder <- "Skellam_share"
functionpath<-substr(dirname(rstudioapi::getSourceEditorContext()$path), 
                     1, unlist(gregexpr(function_folder, 
                                        dirname(rstudioapi::getSourceEditorContext()$path)))+(nchar(function_folder)-1))

setwd(functionpath)

source("1. Code/0. Functions.R")

# train_tot<-readRDS("2. Data/2. Training Data/training_data.rds")
# train<-train_tot
# RKI_Divi_lag<-readRDS("2. Data/2. Training Data/training_data.rds")
# results<-readRDS("3. Model/Model_500_runs.RData")
# 
# source("C:/Users/ra98jiq/Documents/Papers/Covid/functions.R")

###########   Simulation from Skellam    #######################################

rdiffpois = function(lambda.in=lambda0.in, 
                     lambda.out=lambda0.out , 
                      D=data_training$Diff,
                      maxIn=1000){
  ## Funktion zur Simulation des E-step. Dabei wird 
  ## I ~ Poisson (lambda.in) und R ~ Poisson(lambda.out)
  ## simuliert, wobei gelten muss I - R = D
  
  k.in = matrix(rep(c(0: maxIn), each=length(lambda0.in)), nrow=length(lambda0.in))
  
  D=matrix(rep(D, maxIn+1), nrow=length(lambda.in))
  k.out = k.in - D
  index<-(k.in>=0)&(k.out>=0)
  
  
  I<-c()
  R<-c()
  
  for(i in 1:length(lambda0.in)){
    k.in.i = k.in[i,index[i,]]
    k.out.i = k.out[i,index[i,]]
    prob = dpois(k.in.i, lambda= lambda.in[i]) * dpois( k.out.i, lambda = lambda.out[i])
    x=sum(prob)
    if(sum(prob)==0){
      x=1
    }
  
    prob = prob/x
    if(sum(prob)==0){
      prob=rep(1/length(prob), length(prob))
    }
    j = sample(length(prob), 1, prob=prob)
    
    I[i]<-k.in.i[j]
    R[i]<-k.out.i[j]
  }
  
  return(list( I = I, R = R))
}

###########   Simulation Data   ############################################


simulation_data<-function(n=10000, ss=123, delta=0.1, fixed=TRUE){
  #n1=n+1
  set.seed(ss)
  x1var<-1.397
  x1mean<-1.978
  
  # b2_t_in<-((max(results$Coeff_in[,grepl("date", colnames(results$Coeff_in))])
  #             -min(results$Coeff_in[,grepl("date", colnames(results$Coeff_in))]))/
  #   as.numeric(max(train$date)-min(train$date)))
  # 
  # b2_t_out<-(-(max(results$Coeff_out[,grepl("date", 
  #                                           colnames(results$Coeff_out))])
  #             -min(results$Coeff_out[,grepl("date", 
  #                                           colnames(results$Coeff_out))]))/
  #   as.numeric(max(train$date)-min(train$date)))
  
  b2_t_in<-0.0645683
  b2_t_out<--0.01798044
  
  if(round(n/200)!=n/200){print(
    "For this simulation we need an n that's divisible by 200")}
  
  t<-rep(1:(n/200), 200)  
  d<-rep(1:200, each=n/200)
  X1<-rnorm(n, x1mean, sqrt(x1var))
  
  if(fixed){
    b0in<--2.34
    b1in<-0.8
    
    b0out<-0.001
    b1out<-0.1  
  }else{
    b0in<-rnorm(1, -2.340, 0.0567)
    b1in<-rnorm(1,0.8, 0.0250)
    
    b0out<-rnorm(1, 0, 0.0725)
    b1out<-rnorm(1, 0.1, 0.0313)    
  }
  
  yin<-rpois(length(X1), lambda=exp(b0in+b1in*X1+b2_t_in*t))
  
  data_training<-as.data.frame(cbind(yin, X1, t, d))
  
  data_training_temp<-data_training%>%
    dplyr::mutate(t=t+1, yin_lag=yin)%>%
    dplyr::select(t, yin_lag, d)%>%
    full_join(data_training, by=c("d","t"))%>%
    na.omit()

  
  data_training_temp$yout<-rpois(nrow(data_training_temp), 
                                 lambda=exp(b0out+b1out*
                                  data_training_temp$X1
                                        #+b2out*X2+b3out*X3
                                        +log(data_training_temp$yin_lag+
                                               delta)+
                                          b2_t_out*data_training_temp$t))
  
  
  data_training<-data_training_temp 
  data_training$Diff<-data_training$yin-data_training$yout
  
  return(list("Data"=data_training, "Coeff"=c(b0in, b1in, b2_t_in, 
                                              b0out, b1out, b2_t_out)))
}

###########   Variance Calculation  ############################################
RubinVar<-function(Varianceruns=Run1$Coeff_var_in[200:500,,], Coefficientruns=Coeff_in[200:500,], runs=500){
  Rub1<-apply(Varianceruns,c(2,3),mean)
  betaminusbetaline<-(Coefficientruns-
                        matrix(rep(apply(Coefficientruns, 2, mean),
                                   each=nrow(Varianceruns)),
                               nrow=nrow(Varianceruns), ncol=ncol(Coefficientruns)))  
  variance_step<-array(NA,dim=c(nrow(betaminusbetaline), ncol(Coefficientruns),ncol(Coefficientruns)))
  for(i in 1:nrow(betaminusbetaline)){
    variance_step[i,,]<-t(as.matrix(betaminusbetaline[i,]))%*%
      as.matrix(betaminusbetaline[i,])
  }
  Rub2<-apply(variance_step,c(2,3),mean)
  Rubinvars<-Rub1+(1+1/nrow(Varianceruns))*(1/(nrow(Varianceruns)-1))*Rub2
  return(Rubinvars)
}

###########   Model Run  #######################################################
EMsimm<-function(train1=data_training, 
                 runs_tot=500, nr_coef=3, 
                 data_tot=data_training, 
                 delta_out=0.1,
                 lambda0.in=rep(sample(1:floor((max(train1$Diff)-
                                             min(train1$Diff)/2)),1), 
                                nrow(data_training)),
                 lambda0.out=rep(sample(floor(max(train1$Diff)-
                                                        min(train1$Diff)/2):max(train1$Diff),1), 
                                 nrow(data_training))){
  
  start_sim<-rdiffpois(lambda0.in, lambda0.out, train1$Diff)
  diff_sim<-as.data.frame(cbind("ind"=1:100, "sum_I"=1,"sum_R"=1))
  
  fitlist<-list()
  modellist<-list()
  Coeff_in<-NULL
  Coeff_out<-NULL
  
  VCOV<-matrix(0, nr_coef, nr_coef)
  Coeff_var_in<-array(NA, dim=c(runs_tot, nrow(VCOV),ncol(VCOV)))
  Coeff_var_out<-array(NA, dim=c(runs_tot, nrow(VCOV),ncol(VCOV)))
  

  for(k in 1:runs_tot){
    
    I_Mstep<-mgcv::gam(start_sim$I~X1+t, 
                       data=train1, family="poisson")
    R_Mstep<-mgcv::gam(start_sim$R~X1+offset(log(yin_lag+delta_out))+t,
                       data=train1, family="poisson")
    
    Coeff_var_in[k,,]<-vcov(I_Mstep)
    Coeff_var_out[k,,]<-vcov(R_Mstep)
    
    lambda.in.new<-predict.gam(I_Mstep, type="response")
    lambda.out.new<-predict.gam(R_Mstep, type="response")
    
    
    fitlist[[k]]<-rdiffpois(lambda.in.new,lambda.out.new, train1$Diff)
    start_sim<-as.data.frame(cbind("I"=fitlist[[k]]$I, "R"=fitlist[[k]]$R))
    modellist[[k]]<-list("I_mod"=I_Mstep,"R_mod"= R_Mstep)
    
    if(!is.null(Coeff_in)){
      suppressMessages(Coeff_in<-Coeff_in%>%
                         full_join(as.data.frame(t(coef(I_Mstep)))))
    }else{
      Coeff_in<-as.data.frame(t(coef(I_Mstep)))
      
    }
    if(!is.null(Coeff_out)){
      suppressMessages(Coeff_out<-Coeff_out%>%
                         full_join(as.data.frame(t(coef(R_Mstep)))))  
    }else{
      Coeff_out<-as.data.frame(t(coef(R_Mstep)))
    }
    
  }  
  
  Varin<-RubinVar(Varianceruns=Coeff_var_in[200:runs_tot,,], 
                  Coefficientruns=Coeff_in[200:runs_tot,], runs=runs_tot)
  Varout<-RubinVar(Varianceruns=Coeff_var_out[200:runs_tot,,], 
                   Coefficientruns=Coeff_out[200:runs_tot,], runs=runs_tot)
  
  
  return(list("Coeff_in"=Coeff_in, "Coeff_out"=Coeff_out, 
              "Coeff_var_in"=Coeff_var_in, "Coeff_var_out"=Coeff_var_out,
              "Varin"=Varin, "Varout"=Varout, "starvaluein"=unique(lambda0.in),
              "starvalueout"=unique(lambda0.out), "Models"=modellist, 
              "Response"=fitlist))
}


Sim_list<-list()

for(s in 16:20){
  
  data_simulated<-simulation_data(n=10000, ss=s, delta=0.1, fixed=TRUE)
  
  data_training<-data_simulated$Data
  
  set.seed(s)
  lambda0.insim=rep(sample(1:10,1), nrow(data_training))
  lambda0.outsim=rep(sample(11:20,1), nrow(data_training))
  
  Sim1<-EMsimm(lambda0.in=lambda0.insim,
               lambda0.out=lambda0.outsim)
  
  Rez<-NULL
  
  Rez<-cbind("I"=unlist(Sim1$Response)[grepl("I", 
                            names(unlist(Sim1$Response)))],
             "R"=unlist(Sim1$Response)[grepl("R", 
                      names(unlist(Sim1$Response)))])
  
  Rez<-cbind(Rez, "obs"=rep(1:nrow(data_training),
                            length(Sim1$Response)), 
             "Runs"=rep(1:length(Sim1$Response),
                        each=nrow(data_training)))
  Rez<-as.data.frame(Rez)
  
  Rez_mean <- Rez %>%
    dplyr::filter(Runs>200)%>%
    dplyr::group_by(obs) %>%
    dplyr::summarize(I_mean = round(median(I, na.rm=TRUE)),
                     R_mean = round(median(R, na.rm=TRUE)))
  
  Coef_in_out<-cbind(Sim1$Coeff_in, Sim1$Coeff_out)
  names(Coef_in_out)<-c("In_Int", "In_X1", "Out_Int", "Out_X1")
  
  Sim_list[[s]]<-list("Estimated_coef"=Coef_in_out, "Rsults"=Rez_mean,"Real_vars"=data_simulated$Coeff, 
                      "Real_Data"=data_simulated$Data, Varin=Sim1$Varin, Varout=Sim1$Varout)
  saveRDS(Sim_list, 
          "4. Simulation/Simulations_paper_t_d.RData")
  print(s)
}




Sim_list<-readRDS("4. Simulation/Simulations_paper_t_d.RData")


coefficients<-NULL
for(i in 1:length(Sim_list)){
  coef_est<-apply(Sim_list[[i]]$Estimated_coef[200:nrow(Sim_list[[i]]$Estimated_coef),], 2, 
                  median)
  names(coef_est)<-c("In_Int", "In_X1", "tin", "Out_Int", "Out_X1", "tout")
  coef_conf_in<-1.96*sqrt(diag(Sim_list[[i]]$Varin))
  coef_conf_out<-1.96*sqrt(diag(Sim_list[[i]]$Varout))
  coef_conf_min<-c("LoCon_In_Int"=coef_est["In_Int"]-coef_conf_in[1], 
                   "LoCon_In_X1"=coef_est["In_X1"]-coef_conf_in[2], 
                   "LoCon_In_t"=coef_est["tin"]-coef_conf_in[3],
                   "LoCon_Out_Int"=coef_est["Out_Int"]-coef_conf_out[1], 
                   "LoCon_Out_X1"=coef_est["Out_X1"]-coef_conf_out[2], 
                   "LoCon_Out_t"=coef_est["tout"]-coef_conf_out[3])
  coef_conf_max<-c("UpCon_In_Int"=coef_est["In_Int"]+coef_conf_in[1], 
                   "UpCon_In_X1"=coef_est["In_X1"]+coef_conf_in[2], 
                   "UpCon_In_t"=coef_est["tin"]+coef_conf_in[3],
                   "UpCon_Out_Int"=coef_est["Out_Int"]+coef_conf_out[1], 
                   "UpCon_Out_X1"=coef_est["Out_X1"]+coef_conf_out[2], 
                   "UpCon_Out_t"=coef_est["tout"]+coef_conf_out[3])
  names(Sim_list[[i]]$Real_vars)<-c("Real_In_Int", "Real_In_X1", "Real_In_t",
                                    "Real_Out_Int", "Real_Out_X1", "Real_Out_t")
  real_est<-Sim_list[[i]]$Real_vars
  coefficients<-rbind(coefficients, c(coef_est, 
                                      coef_conf_min, 
                                      coef_conf_max, 
                                      real_est))
}

coefficients<-as.data.frame(coefficients)
names(coefficients)<-c("Est_In_Int", "Est_In_X1", "Est_In_t", 
                       "Est_Out_Int", "Est_Out_X1", "Est_Out_t",
                       "LoCon_In_Int", "LoCon_In_X1", "LoCon_In_t",
                       "LoCon_Out_Int", "LoCon_Out_X1", "LoCon_Out_t",
                       "UpCon_In_Int", "UpCon_In_X1", "UpCon_In_t",
                      "UpCon_Out_Int", "UpCon_Out_X1", "UpCon_Out_t",
                      "Real_In_Int", "Real_In_X1", "Real_In_t",
                      "Real_Out_Int", "Real_Out_X1", "Real_Out_t")

coefficients$int<-1:nrow(coefficients)


gin_int<-ggplot(coefficients)+
  geom_point(aes(x=int, y=Real_In_Int, col="Simulated Coefficient"))+
  geom_segment(aes(x=int, xend=int, y=LoCon_In_Int,  yend=UpCon_In_Int, col="Estimated Coefficient"))+
  geom_point(aes(x=int, y=Est_In_Int, col="Estimated Coefficient"))+
  theme(legend.position = "none")+
  geom_hline(aes(yintercept=0), linetype = 2)+
  geom_hline(aes(yintercept=min(Real_In_Int), col="Simulated Coefficient"))+
  xlab("Simulation Number")+
  ylab("Coefficient")+
  ggtitle("Incoming Intercept")+
  theme_pubr()+
  scale_color_manual(values=cbPalette[c(7,6)])+
  labs(col = "")

gin_x1<-ggplot(coefficients)+
  geom_point(aes(x=int, y=Real_In_X1, col="Simulated Coefficient"))+
  geom_segment(aes(x=int, xend=int, y=LoCon_In_X1,  
                   yend=UpCon_In_X1, col="Estimated Coefficient"))+
  geom_point(aes(x=int, y=Est_In_X1, col="Estimated Coefficient"))+
  theme(legend.position = "none")+
  geom_hline(aes(yintercept=0), linetype = 2)+
  geom_hline(aes(yintercept=min(Real_In_X1), col="Simulated Coefficient"))+
  xlab("Simulation Number")+
  ylab("Coefficient")+
  ggtitle("Incoming X1")+
  theme_pubr()+
  scale_color_manual(values=cbPalette[c(7,6)])+
  labs(col = "")


gin_t<-ggplot(coefficients)+
  geom_point(aes(x=int, y= Real_In_t, col="Simulated Coefficient"))+
  geom_segment(aes(x=int, xend=int, y=LoCon_In_t,  yend=UpCon_In_t, 
                   col="Estimated Coefficient"))+
  geom_point(aes(x=int, y=Est_In_t, col="Estimated Coefficient"))+
  theme(legend.position = "none")+
  geom_hline(aes(yintercept=0), linetype = 2)+
  geom_hline(aes(yintercept=min(Real_In_t), 
                 col="Simulated Coefficient"))+
  xlab("Simulation Number")+
  ylab("Coefficient")+
  ggtitle("Incoming Trend")+
  theme_pubr()+
  scale_color_manual(values=cbPalette[c(7,6)])+
  labs(col = "")


gout_int<-ggplot(coefficients)+
  geom_point(aes(x=int, y=Real_Out_Int, col="Simulated Coefficient"))+
  geom_segment(aes(x=int, xend=int, 
                   y=LoCon_Out_Int,  
                   yend=UpCon_Out_Int, col="Estimated Coefficient"))+
  geom_point(aes(x=int, y=Est_Out_Int, col="Estimated Coefficient"))+
  theme(legend.position = "none")+
  geom_hline(aes(yintercept=0), linetype = 2)+
  geom_hline(aes(yintercept=min(Real_Out_Int) , col="Simulated Coefficient"))+
  xlab("Simulation Number")+
  ylab("Coefficient")+
  ggtitle("Outgoing Intercept")+
  theme_pubr()+
  scale_color_manual(values=cbPalette[c(7,6)])+
  labs(col = "")

gout_x1<-ggplot(coefficients)+
  geom_point(aes(x=int, y=Real_Out_X1, col="Simulated Coefficient"))+
  geom_segment(aes(x=int, xend=int, y=LoCon_Out_X1,  yend=UpCon_Out_X1, col="Estimated Coefficient"))+
  geom_point(aes(x=int, y=Est_Out_X1, col="Estimated Coefficient"))+
  theme(legend.position = "none")+
  geom_hline(aes(yintercept=0), linetype = 2)+
  geom_hline(aes(yintercept=min(Real_Out_X1), col="Simulated Coefficient"))+
  xlab("Simulation Number")+
  ylab("Coefficient")+
  ggtitle("Outgoing X1")+
  theme_pubr()+
  scale_color_manual(values=cbPalette[c(7,6)])+
  labs(col = "")


gout_t<-ggplot(coefficients)+
  geom_point(aes(x=int, y= Real_Out_t, col="Simulated Coefficient"))+
  geom_segment(aes(x=int, xend=int, 
                   y=LoCon_Out_t,  yend=UpCon_Out_t, 
                   col="Estimated Coefficient"))+
  geom_point(aes(x=int, y=Est_Out_t, col="Estimated Coefficient"))+
  theme(legend.position = "none")+
  geom_hline(aes(yintercept=0), linetype = 2)+
  geom_hline(aes(yintercept=min(coefficients$Real_Out_t), 
                 col="Simulated Coefficient"))+
  xlab("Simulation Number")+
  ylab("Coefficient")+
  ggtitle("Outgoing Trend")+
  theme_pubr()+
  scale_color_manual(values=cbPalette[c(7,6)])+
  labs(col = "")


simulation_coefs<-plot_grid(gin_int, gout_int,
                            gin_x1, gout_x1, 
                            gin_t, gout_t, ncol=2)

# ggsave(simulation_coefs, 
#        filename="4. Simulation/simulation_coeffcients_w_t_d.pdf",
#        device="pdf", width=10, height=8)





estimatedIncom1<-ggplot()+
  geom_line(aes(x=(1:length(Sim_list[[1]]$Rsults$I_mean))/length(Sim_list[[1]]$Rsults$I_mean)*
                  max(Sim_list[[1]]$Rsults$I_mean), 
                y=(1:length(Sim_list[[1]]$Rsults$I_mean))/length(Sim_list[[1]]$Rsults$I_mean)*
                  max(Sim_list[[1]]$Rsults$I_mean)),
            col=cbPalette[7])+
  geom_point(aes(y=Sim_list[[1]]$Rsults$I_mean, 
                 x=Sim_list[[1]]$Real_Data$yin),
             alpha=0.1, col=cbPalette[7])+
  theme_pubr()+
  xlab("Real")+
  ylab("Estimated")+
  ggtitle("Simulation 1: Incoming Patients")


estimatedOutgo1<-ggplot()+
  geom_line(aes(x=(1:length(Sim_list[[1]]$Rsults$R_mean))/length(Sim_list[[1]]$Rsults$R_mean)*
                  max(Sim_list[[1]]$Rsults$R_mean), 
                y=(1:length(Sim_list[[1]]$Rsults$R_mean))/length(Sim_list[[1]]$Rsults$R_mean)*
                  max(Sim_list[[1]]$Rsults$R_mean)),
            col=cbPalette[6])+
  geom_point(aes(y=Sim_list[[1]]$Rsults$R_mean, 
                 x=Sim_list[[1]]$Real_Data$yout),
             alpha=0.1, col=cbPalette[6])+
  theme_pubr()+
  xlab("Real")+
  ylab("Estimated")+
  ggtitle("Simulation 1: Outgoing Patients")



estimatedIncom2<-ggplot()+
  geom_line(aes(x=(1:length(Sim_list[[2]]$Rsults$I_mean))/length(Sim_list[[2]]$Rsults$I_mean)*
                  max(Sim_list[[2]]$Rsults$I_mean), 
                y=(1:length(Sim_list[[2]]$Rsults$I_mean))/length(Sim_list[[2]]$Rsults$I_mean)*
                  max(Sim_list[[2]]$Rsults$I_mean)),
            col=cbPalette[7])+
  geom_point(aes(y=Sim_list[[2]]$Rsults$I_mean, 
                 x=Sim_list[[2]]$Real_Data$yin),
             alpha=0.1, col=cbPalette[7])+
  theme_pubr()+
  xlab("Real")+
  ylab("Estimated")+
  ggtitle("Simulation 2: Incoming Patients")


estimatedOutgo2<-ggplot()+
  geom_line(aes(x=(1:length(Sim_list[[2]]$Rsults$R_mean))/length(Sim_list[[2]]$Rsults$R_mean)*
                  max(Sim_list[[2]]$Rsults$R_mean), 
                y=(1:length(Sim_list[[2]]$Rsults$R_mean))/length(Sim_list[[2]]$Rsults$R_mean)*
                  max(Sim_list[[2]]$Rsults$R_mean)),
            col=cbPalette[6])+
  geom_point(aes(y=Sim_list[[2]]$Rsults$R_mean, 
                 x=Sim_list[[2]]$Real_Data$yout),
             alpha=0.1, col=cbPalette[6])+
  theme_pubr()+
  xlab("Real")+
  ylab("Estimated")+
  ggtitle("Simulation 2: Outgoing Patients")



estimatedIncom3<-ggplot()+
  geom_line(aes(x=(1:length(Sim_list[[3]]$Rsults$I_mean))/length(Sim_list[[3]]$Rsults$I_mean)*
                  max(Sim_list[[3]]$Rsults$I_mean), 
                y=(1:length(Sim_list[[3]]$Rsults$I_mean))/length(Sim_list[[3]]$Rsults$I_mean)*
                  max(Sim_list[[3]]$Rsults$I_mean)),
            col=cbPalette[7])+
  geom_point(aes(y=Sim_list[[3]]$Rsults$I_mean, 
                 x=Sim_list[[3]]$Real_Data$yin),
             alpha=0.1, col=cbPalette[7])+
  theme_pubr()+
  xlab("Real")+
  ylab("Estimated")+
  ggtitle("Simulation 3: Incoming Patients")


estimatedOutgo3<-ggplot()+
  geom_line(aes(x=(1:length(Sim_list[[3]]$Rsults$R_mean))/length(Sim_list[[3]]$Rsults$R_mean)*
                  max(Sim_list[[3]]$Rsults$R_mean), 
                y=(1:length(Sim_list[[3]]$Rsults$R_mean))/length(Sim_list[[3]]$Rsults$R_mean)*
                  max(Sim_list[[3]]$Rsults$R_mean)),
            col=cbPalette[6])+
  geom_point(aes(y=Sim_list[[3]]$Rsults$R_mean, 
                 x=Sim_list[[3]]$Real_Data$yout),
             alpha=0.1, col=cbPalette[6])+
  theme_pubr()+
  xlab("Real")+
  ylab("Estimated")+
  ggtitle("Simulation 3: Outgoing Patients")


sim1<-plot_grid(estimatedIncom1, estimatedOutgo1, nrow=1)
sim2<-plot_grid(estimatedIncom2, estimatedOutgo2, nrow=1)
sim3<-plot_grid(estimatedIncom3, estimatedOutgo3, nrow=1)


# ggsave(plot_grid(sim1, sim2, sim3, ncol=1),
#        file="4. Simulation/SimulationRealvsEst_t_d.pdf",
#        device="pdf",
#        width=7, height=10)

















