############################################################################################
date_tod<-gsub("-", "_", as.character(Sys.Date()))
Sys.setlocale("LC_TIME", "English")
Sys.setenv("LANGUAGE"="English")


function_folder <- "Skellam_share"
functionpath<-substr(dirname(rstudioapi::getSourceEditorContext()$path), 
                     1, unlist(gregexpr(function_folder, 
                                        dirname(rstudioapi::getSourceEditorContext()$path)))+
                       (nchar(function_folder)-1))

setwd(functionpath)

source("1. Code/0. Functions.R")
library("forecast")

train_tot<-readRDS("2. Data/2. Training Data/training_data.rds")

train<-train_tot%>%
  filter(date>as.Date("2021-10-01"), date<as.Date("2021-11-18"))



###############################################################################
results<-readRDS("3. Model/Model_500_runs.RData")
results$Varout<-RubinVar(Varianceruns=results$Coeff_var_out[200:500,,], 
                         Coefficientruns=results$Coeff_out[200:500,-1], runs=500)
results$Varin<-RubinVar(Varianceruns=results$Coeff_var_in[200:500,,], 
                        Coefficientruns=results$Coeff_in[200:500,-1], runs=500)


###############################################################################

Diff_resid<-(train$Diff-(resid_stan$Prediction$Predict_Incoming-resid_stan$Prediction$Predict_Outgoing))/
  sqrt((resid_stan$Prediction$Predict_Incoming+resid_stan$Prediction$Predict_Outgoing))

Diff_resid<-cbind(Diff_resid, resid_stan$Prediction, "date"=train$date, 
                  "districtId"=train$districtId)

Sum_by_date<-resid_stan$Prediction%>%
  dplyr::group_by(date)%>%
  dplyr::summarize(Total_Incoming_pred=sum(Predict_Incoming), 
                   Total_Outgoing_pred=sum(Predict_Outgoing),
                   Total_Incoming_res=sum(Sim_Incoming), 
                   Total_Outgoing_res=sum(Sim_Incoming))


Sum_by_date_diff<-Diff_resid%>%
  dplyr::group_by(date)%>%
  dplyr::summarize(Total_Diff_pred=sum(Diff_resid))

stan_res_tot_inc<-(Sum_by_date$Total_Incoming_pred-
                     Sum_by_date$Total_Incoming_res)/sqrt(var(Sum_by_date$Total_Incoming_pred-
                                                                Sum_by_date$Total_Incoming_res))

stan_res_tot_out<-(Sum_by_date$Total_Outgoing_pred-
                     Sum_by_date$Total_Outgoing_res)/sqrt(var(Sum_by_date$Total_Outgoing_pred-
                                                                Sum_by_date$Total_Outgoing_res))


acfin<-acf(stan_res_tot_inc)
pacfin<-pacf(stan_res_tot_inc)
acfout<-acf(stan_res_tot_out)
pacfout<-pacf(stan_res_tot_out)



ginACF<-ggAcf(stan_res_tot_inc)+
  ggtitle("ACF of Standardized residuals of incoming patients")
ginPACF<-ggAcf(stan_res_tot_inc, "partial")+
  ggtitle("PACF of Standardized residuals of incoming patients")
goutACF<-ggAcf(stan_res_tot_out)+
  ggtitle("ACF of Standardized residuals of outgoing patients")
goutPACF<-ggAcf(stan_res_tot_out, "partial")+
  ggtitle("PACF of Standardized residuals of outgoing patients")
gdiffACF<-ggAcf(Sum_by_date_diff$Total_Diff_pred)+
  ggtitle("ACF of Standardized residuals of the Difference")
gdiffPACF<-ggAcf(Sum_by_date_diff$Total_Diff_pred, "partial")+
  ggtitle("PACF of Standardized residuals of the Difference")


plot_grid(ginACF, goutACF, ginPACF, goutPACF, nrow=2)
plot_grid(gdiffACF, gdiffPACF, nrow=2)

setwd("3. Model/ACF/DifferenceACFbydistrict")
names<-as.data.frame(unique(train[,c("district", "districtId")]))
names$districtId<-as.numeric(names$districtId)


ACF_PACFbydist<-NULL
for(i in 1:length(unique(Diff_resid$districtId))){
  district_ACF<-Diff_resid%>%
    dplyr::filter(districtId==unique(districtId)[i])
  acf_calc<-acf(district_ACF$Diff_resid)
  pacf_calc<-pacf(district_ACF$Diff_resid)
  
  ACF_PACFbydist<-rbind(ACF_PACFbydist, 
                        cbind("districtId"=unique(Diff_resid$districtId)[i], 
                              "Lag"=1:length(acf_calc$acf),
                              "ACF"=acf_calc$acf, 
                              "PACF"=pacf_calc$acf))
  
  
  # gdiffACFdist<-ggAcf(district_ACF$Diff_resid)+
  #   ggtitle("ACF of Standardized residuals of incoming patients", 
  #           paste("District", 
  #                 names$district[names$districtId==
  #                                  unique(Diff_resid$districtId)[i]]))
  # gdiffPACFdist<-ggAcf(district_ACF$Diff_resid, "partial")+
  #   ggtitle("PACF of Standardized residuals of incoming patients")
  # 
  # plot_acf_pacf<-plot_grid(gdiffACFdist, gdiffPACFdist, nrow=2)
  # 
  # ggsave(plot_acf_pacf, file=paste0("ACF_District", unique(
  #   Diff_resid$districtId)[i] , ".png"),
  #        height=8, width=5)
}


ACF_PACFbydist<-as.data.frame(ACF_PACFbydist)

max(Diff_resid$date)-min(Diff_resid$date)

ggacf_all_dist<-ggplot(ACF_PACFbydist)+
  geom_line(aes(x=Lag, y=ACF, col=as.factor(districtId)), alpha=0.2)+
  theme(legend.position = "none")+
  geom_hline(aes(yintercept=c(1)*1.96/sqrt(max(46)-1)), 
             col="blue", linetype = "dashed")+
  geom_hline(aes(yintercept=c(-1)*1.96/sqrt(max(46)-1)), 
             col="blue", linetype = "dashed")

ggpacf_all_dist<-ggplot(ACF_PACFbydist)+
  geom_line(aes(x=Lag, y=PACF, col=as.factor(districtId)), alpha=0.2)+
  theme(legend.position = "none")+
  geom_hline(aes(yintercept=c(1)*1.96/sqrt(max(46)-1)), 
             col="blue", linetype = "dashed")+
  geom_hline(aes(yintercept=c(-1)*1.96/sqrt(max(46)-1)), 
             col="blue", linetype = "dashed")

Outgoing=as.data.frame(predict(results_stand$Models[[runs[i]]]$I_mod, 
                               type="response"))

# ggsave(plot_grid(ggacf_all_dist,ggpacf_all_dist, nrow=2), 
#        file=paste0(
#          "3. Model/ACF/ACF_District_all.png"),
#        height=8, width=5)






