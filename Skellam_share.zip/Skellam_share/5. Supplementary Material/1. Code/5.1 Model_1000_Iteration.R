
############################################################################################
date_tod<-gsub("-", "_", as.character(Sys.Date()))
Sys.setlocale("LC_TIME", "English")
Sys.setenv("LANGUAGE"="English")


function_folder <- "Skellam_share"
functionpath<-substr(dirname(rstudioapi::getSourceEditorContext()$path), 
                     1, unlist(gregexpr(function_folder, 
                                        dirname(rstudioapi::getSourceEditorContext()$path)))+
                       (nchar(function_folder)-1))

setwd(functionpath)

source("1. Code/0. Functions.R")

train_tot<-readRDS("2. Data/2. Training Data/training_data.rds")

train<-train_tot%>%
  filter(date>as.Date("2021-10-01"), date<as.Date("2021-11-18"))



############################################################################################


train_train=train
runs1=1000
data_tot= train_tot
formula_in=as.formula(I_sim ~ weekday + 
                        s(as.numeric(date), bs = "ps") + 
                        G_4_7_lag_1 + 
                        G_5_7_lag_1 + 
                        G_6_7_lag_1 + 
                        s(lat, long, bs = "tp"))
formula_out=as.formula(R_sim ~ weekday + 
                         s(as.numeric(date), bs = "ps") + 
                         G_4_7_lag_1 + 
                         G_5_7_lag_1 + 
                         G_6_7_lag_1 + 
                         s(lat, long, bs = "tp"))
nr_coefficients=48

lambda0.in<-rep(results$starvaluein, nrow(train_train))
lambda0.out<-rep(results$starvalueout, nrow(train_train))

start_sim<-rdiffpois(lambda0.in,lambda0.out, train_train$Diff)

train_train$I_sim<-start_sim$I
train_train$R_sim<-start_sim$R

fitlist<-list()
modellist<-list()
Coeff_in<-NULL
Coeff_out<-NULL

nr_coef_in<-nr_coefficients
nr_coef_out<-nr_coefficients

VCOV_in<-matrix(0, nr_coef_in, nr_coef_in)
VCOV_out<-matrix(0, nr_coef_out, nr_coef_out)

Coeff_var_in<-array(NA, dim=c(runs1, nrow(VCOV_in),ncol(VCOV_in)))
Coeff_var_out<-array(NA, dim=c(runs1, nrow(VCOV_out),ncol(VCOV_out)))
loglike<-c()
survival_days<-c(1:56)
survival_prob<-c(0.20, 0.32, 0.4, 0.46, 0.51, 
                 0.55, 0.57, 0.60, 0.63, 0.69,
                 0.71, 0.73, 0.74, 0.77, 0.78,
                 0.79,seq(0.82, 1, by=(1-0.82)/(56-17)))
suvdays<-cbind("days"=survival_days, "prob"=survival_prob)

for(k in 1:runs1){
  train_train$I_sim<- start_sim$I
  train_train$R_sim<- start_sim$R
  
  Msteprun<-Mstep(train1=train_train, 
                  formula_in1=formula_in, 
                  formula_out1=formula_out, 
                  data_tot1=data_tot)
  
  Coeff_var_in[k,,]<-vcov(Msteprun$I_Mstep)
  Coeff_var_out[k,,]<-vcov(Msteprun$R_Mstep)
  lambda.in.new<-predict(Msteprun$I_Mstep, type="response")
  lambda.out.new<-predict(Msteprun$R_Mstep, type="response")
  
  loglike[k]<-sum(log(pskellam(train_train$Diff, lambda.in.new, 
                               lambda.out.new)))
  
  print(paste("iteration", k, "is done"))
  fitlist[[k]]<-rdiffpois(lambda.in.new,lambda.out.new, train1$Diff)
  start_sim<-as.data.frame(cbind("I"=fitlist[[k]]$I, "R"=fitlist[[k]]$R))
  
  modellist[[k]]<-list("I_mod"=Msteprun$I_Mstep,"R_mod"= Msteprun$R_Mstep)
  if(k!=1){
    Coeff_in<-rbind(Coeff_in, as.data.frame(cbind(k, 
                                                  t(coef(Msteprun$I_Mstep)))))
    Coeff_out<-rbind(Coeff_out, as.data.frame(cbind(k, 
                                                    t(coef(Msteprun$R_Mstep)))))
    # suppressMessages(Coeff_out<-Coeff_out%>%
    #                    full_join(as.data.frame(t(coef(Msteprun$R_Mstep)))))
  }else{
    Coeff_in<-as.data.frame(cbind(k, t(coef(Msteprun$I_Mstep))))
    Coeff_out<-as.data.frame(cbind(k, t(coef(Msteprun$R_Mstep))))
    
  }
  
}

model_1000_Iteration<-list("Coeff_in"=Coeff_in, "Coeff_out"=Coeff_out, 
                       "Coeff_var_in"=Coeff_var_in, "Coeff_var_out"=Coeff_var_out,
                       # "Varin"=Varin, "Varout"=Varout, 
                       "starvaluein"=unique(lambda0.in),
                       "starvalueout"=unique(lambda0.out), "Models"=modellist, 
                       "Response"=fitlist#, "tav"=tav1, "tot_days"=tot_days2
)



# saveRDS(model_1000_Iteration, 
#         file="3. Model/Output_1000k/Model_1000_runs.RData") 



